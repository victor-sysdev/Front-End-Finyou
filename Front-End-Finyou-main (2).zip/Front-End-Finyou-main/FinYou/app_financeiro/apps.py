from django.apps import AppConfig


class AppFinanceiroConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "app_financeiro"
    verbose_name = "FinYOU"
