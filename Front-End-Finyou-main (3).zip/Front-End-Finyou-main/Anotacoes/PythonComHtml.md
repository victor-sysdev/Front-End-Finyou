# Comandos
Os seguintes comandos são utilizados dentro dos arquivos HTML para adicionar dinamismo às páginas web criadas com django.

## Tópicos a serem abordados
 - Variáveis
 - Laços de Repetições
 - Funções
 - Estruturas de caso


### Variáveis
{{ nome_variavel }}

### Laços de Repetições
{% for %}